#!/bin/bash
./scripts/QUALITYPIPELINE_test.sh ./INPUT_test ./OUTPUT_QUALITYPIPELINE ./work