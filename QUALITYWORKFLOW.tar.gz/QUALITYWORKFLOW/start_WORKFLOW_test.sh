#!/bin/bash
#Test a complete workflow
rm ./OUTPUT/*
./scripts/WORKFLOW_test.sh ./INPUT_test ./OUTPUT ./work