#!/bin/bash
cp $egressIN1 $egressOUT1 &
cp $egressIN2 $egressOUT2 &
cp $egressIN3 $egressOUT3
