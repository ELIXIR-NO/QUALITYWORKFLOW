#!/bin/bash
cp $ingressIN1 $ingressOUT1 &
cp $ingressIN2 $ingressOUT2