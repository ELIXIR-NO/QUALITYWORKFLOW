#!/bin/bash
#Resume a halted workflow
./scripts/WORKFLOW_resume.sh