#!/bin/bash
#Execute a production workflow
unlink ./INGRESS
unlink ./EGRESS
ln -s $1 ./INGRESS
ln -s $2 ./EGRESS
./scripts/clean.sh
nohup conda run -n nextflow_24.04.4 nextflow -log ./EGRESS/QUALITYWORKFLOW.log run -profile PRODUCTION -w ./work -N "YOUREMAILADDRESS" main.nf > ./EGRESS/QUALITYWORKFLOW.out &