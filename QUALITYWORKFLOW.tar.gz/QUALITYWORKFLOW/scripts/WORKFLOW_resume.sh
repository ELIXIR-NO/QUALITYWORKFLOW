#!/bin/bash
nohup conda run -n nextflow_24.04.4 nextflow -log ./EGRESS/QUALITYWORKFLOW.log run -profile PRODUCTION -w ./work -N "YOUREMAILADDRESS" main.nf -resume 00000000-0000-0000-0000-000000000000 > ./EGRESS/QUALITYWORKFLOW_resume.out &
