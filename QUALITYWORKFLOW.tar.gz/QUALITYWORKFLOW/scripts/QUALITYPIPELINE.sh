#!/bin/bash
unlink ./INGRESS
unlink ./EGRESS
ln -s $1 ./INGRESS
ln -s $2 ./EGRESS
./scripts/clean.sh
nohup conda run -n nextflow_24.04.4 nextflow -log ./EGRESS/QUALITYPIPELINE.log run -profile QUALITYPIPELINE -w ./work -N "YOUREMAILADDRESS" ./modules/QUALITYPIPELINE/main.nf > ./EGRESS/QUALITYPIPELINE.out &