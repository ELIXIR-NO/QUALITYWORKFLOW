#!/bin/bash
echo Starting cleaning workspace...
rm -r ./work/??
rm .nextflow.*
rm -r .nextflow
echo ... finished cleaning workspace.
