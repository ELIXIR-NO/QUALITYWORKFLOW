#!/bin/bash
#Execute a complete workflow
./scripts/WORKFLOW.sh ./INPUT ./OUTPUT ./work